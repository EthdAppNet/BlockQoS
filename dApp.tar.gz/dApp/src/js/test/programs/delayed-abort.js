setTimeout(function() {
  process.exit(99);
}, 0);

