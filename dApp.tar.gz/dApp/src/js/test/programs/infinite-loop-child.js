var y = 1;

while (true) {
  y += 1;
}
