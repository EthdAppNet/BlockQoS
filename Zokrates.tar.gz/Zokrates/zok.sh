zokrates compile -i run.zok
wait 
zokrates setup 
wait
zokrates compute-witness -a $1 $2 $3 $4
wait
zokrates generate-proof
wait
zokrates export-verifier
wait
