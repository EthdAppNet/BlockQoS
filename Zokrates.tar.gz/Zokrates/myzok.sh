zokrates compute-witness -a $1 $2 $3 $4
wait
zokrates generate-proof
wait

