fetch('./proof.json').then(resp=>resp.json())
.then(packageJson) => {
	console.log(packageJson.version);
}