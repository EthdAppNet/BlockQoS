import matplotlib.pyplot as plt
import numpy as np

x = [0,1,2,3,4,5,6,7,8,9,10] 
y =  [0,10,20,30,40,50,60,70,80,90,100]
plt.plot(x, y, color='blue', label='ONSP')
# Add title and axis names
#plt.title('ONSP Session')
plt.xlabel(r'$ONSP_{pay}\,\,computations\,/\,proof$')
plt.ylabel('ONSP sessions')
plt.grid()
#plt.legend()
plt.show()
