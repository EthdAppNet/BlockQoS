import numpy as np
import matplotlib.pyplot as plt
y = [1,1,10,70]
x = ['(One-time trusted setup)', '(Witness)', '(Proof generation)', ('Proof Verification')]
n_groups = 2
index = np.arange(n_groups)
bars =plt.bar(x, y,color=['grey', 'orange', 'blue', 'forestgreen'],  align='center', width=0.2)
plt.xlabel("Zokrates components")
plt.ylabel("Latency (ms)")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("zk-SNARK Off-chain components")
plt.show()