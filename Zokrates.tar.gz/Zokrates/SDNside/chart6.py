import numpy as np
import matplotlib.pyplot as plt
y = [55114,6101]
x = ['On-chain solution', 'BlockQoS model']
bars =plt.bar(x, y,color=['red', 'green'],  width=0.5)
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x()+0.19, yval + .015, yval)
plt.xlabel("Solutions")
plt.ylabel("Gas")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("Total Gas consumption per session")
plt.show()