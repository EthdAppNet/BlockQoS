import matplotlib.pyplot as plt
import numpy as np
x = [0,10,20,30,40,50,60,70,80,90,100] 
y = [0,40, 80, 120, 160, 200, 240, 280, 320, 360, 400]
z  = [0,40, 80, 120, 160, 200, 240, 280, 320, 360, 400]
w= [0,70, 140, 210, 280, 350, 420, 490, 560, 630, 700]

plt.plot(x, z, color='blue',linestyle='-.', label='BlockQoS')
plt.plot(x, y,  color='green', linestyle='--', label='Centralized')
plt.plot(x, w,  color='orange', linestyle='--', label='On-chain')
# Add title and axis names
#plt.title('ONSP Session')
plt.xlabel('Sessions')
plt.ylabel('Latency (ms)')
plt.grid()
plt.legend()
plt.show()