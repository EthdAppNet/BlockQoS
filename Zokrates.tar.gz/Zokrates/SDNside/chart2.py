import matplotlib.pyplot as plt
import numpy as np

x = ['t1','t2', 't3','t4','t5','t6','t7','t8','t9','t10','t11','t12','t13','t14','t15','t16','t17'] 
y =  [50, 50, 50, 50, 50, 50, 1800, 50, 50, 50, 50, 50,50, 50, 50, 50, 50]
a = ['t8','t9', 't10']
b =  [50,1800, 50] 
plt.step(x, y, color="red", label='ONSP Request')
plt.step(a, b, color="green", label='ONSP Implement',linestyle='--')
plt.axhline(y=50, color='b', linestyle='-', label='Base Subscription')
# Add title and axis names
#plt.title('ONSP Session')
plt.xlabel('Time (Instance)')
plt.ylabel('Bandwidth (Mbps)')
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
plt.legend()
plt.show()