var cors = require('cors');
var express = require('express');
const {exec} = require ('child_process');
const fs = require ('fs'); 
var app = express();
const fetch = require ("node-fetch");
const plotlib = require('nodeplotlib');
var count= 0; 
var stdoutext;
//initializing zokrates 1)compile 2)compue witness 3)generate proof 4)export verifier 
 
app.use(cors());
app.get('/', function (req, res) {
    res.send('<b>Instruction towards the controller</b> ');
});
// route with parameters
// matches to : /books/stephenking/category/horror
app.get('/onsp', function(req, res) {
	var bw= req.param('_bw');
	bw = bw * 1000000; 
	//console.log('sh SDN.sh'+' '+bw);
	//first clear the existing queue 
    const SDNctl =exec ('sh SDNclear.sh'+' '+bw, 
	(error, stdout, stderr) => {
			stdoutext= stdout;
		console.log(stdout);
		console.log(stderr);
		if (error !==null){
			console.log('exec error : ${error}');
		}
	});
    //console.log(req.params);
   // var username = req.params.user;
   // var category = req.paramas.categorySlug;
res.send(stdoutext);
   // res.send ('<b>My</b> my lil success')
});
app.use(function(req, res, next) {
    res.status(404).send("Sorry, that route doesn't exist. Have a nice day :)");
});
app.listen(3600, function () {
    console.log('Example app listening on port 3600.');
});

const data = [{
  x: [ 20, 3, 4, 6, 7],
  y: [ 2, 4, 6, 6, 6, 8, 9],
  type: 'step'
}];
var layout = {
  title: 'Title of the Graph',
  xaxis: {
    title: 'x-axis title'
  },
  yaxis: {
    title: 'y-axis title'
  };
plotlib.plot(data, layout);