import matplotlib.pyplot as plt
import numpy as np

x = [1,2,3,4,5,6,7,8,9,10] 
y =  [26807,13403,8935,6701,5361,4467,3829,3475,2978,2680]
plt.plot(x, y, color='blue', label='ONSP')
# Add title and axis names
#plt.title('ONSP Session')
plt.xlabel(r'$User\; Sessions\; per\;BlockQoS_{pay}\;Computation$')
plt.ylabel('Gas')
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
plt.grid(axis = 'x', linestyle = '--', linewidth = 0.5,alpha=1)
for a,b in zip(x, y): 
    plt.text(a-0.09, b+0.9 ,str(b), color="black", size="small")
#plt.legend()
plt.show()