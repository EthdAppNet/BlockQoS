import numpy as np
import matplotlib.pyplot as plt
y = [27911,26807,342129]
x = ['(Base Subscription)', '(BlockQoS Session Manager)', '(Verifier)']
n_groups = 2
index = np.arange(n_groups)
bars =plt.bar(x, y,color=['peru', 'seagreen', 'steelblue'],  align='center', width=0.3)
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x()+0.025, yval + .03, yval)
plt.ylabel("Gas units")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("On-chain solution")
plt.show()