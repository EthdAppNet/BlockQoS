import numpy as np
import matplotlib.pyplot as plt
y = [55114,6101]
x = ['(Baseline Solution)', '(BlockQoS Model)']
n_groups = 2
index = np.arange(n_groups)
bars =plt.bar(x, y,color=['cornflowerblue', 'seagreen'],  align='center', width=0.3)
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x()+0.09, yval + .03, yval)
plt.ylabel("Gas units")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("On-chain solution")
plt.show()