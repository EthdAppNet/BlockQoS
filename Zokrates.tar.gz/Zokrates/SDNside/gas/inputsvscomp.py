import numpy as np
import matplotlib.pyplot as plt
y = [1,2,3,4,5,6,7,8,9,10]
x = [1,2,3,4,5,6,7,8,9,10]

bars =plt.bar(x, y,  align='center')
for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x()-0.55, yval+0.025, str(yval) +'0'+''+'Sessions')
plt.xlabel(r'$BlockQoS_{pay}\;Computations\;/\;Proof$')
plt.ylabel("No. of Inputs")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("On-chain solution")
plt.show()