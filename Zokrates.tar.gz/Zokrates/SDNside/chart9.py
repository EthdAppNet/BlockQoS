import numpy as np
import matplotlib.pyplot as plt
y = [2,3,3]
x = ['Base Subscription', 'BlockQoS Session Manager', 'SDN']
n_groups = 2
index = np.arange(n_groups)
bars =plt.bar(x, y,color=['peru', 'seagreen', 'steelblue'],  align='center', width=0.2)
#plt.xlabel("On-chain solution")
plt.ylabel("Latency (ms)")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("Proposed ONSP solution")
plt.show()