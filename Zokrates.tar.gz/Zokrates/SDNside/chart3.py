import matplotlib.pyplot as plt
import numpy as np

x = [0,1,2,3,4,5,6,7,8,9,10] 
y =  [0,1,2,3,4,5,6,7,8,9,10]
plt.plot(x, y, color='green', label='User sessions')
# Add title and axis names
#plt.title('ONSP Session')
 
plt.text(1, 1, "10 sessions", color="black", size="xx-small")
plt.text(2, 2, "20 sessions", color="black", size="xx-small")
plt.text(3, 3, "30 sessions", color="black", size="xx-small")
plt.text(4, 4, "40 sessions", color="black", size="xx-small")
plt.text(5, 5, "50 sessions", color="black", size="xx-small")
plt.text(6, 6, "60 sessions", color="black", size="xx-small")
plt.text(7, 7, "70 sessions", color="black", size="xx-small")
plt.text(8, 8, "80 sessions", color="black", size="xx-small")
plt.text(9, 9, "90 sessions", color="black", size="xx-small")
plt.text(10, 10, "100 sessions", color="black", size="xx-small")


plt.xlabel('No. of inputs')
plt.ylabel(r'$ONSP_{pay}\,\,computations\,/\,proof$')
plt.grid(axis = 'y', linestyle = '-', linewidth = 0.5,alpha=1)
plt.legend()
plt.show()



#axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1