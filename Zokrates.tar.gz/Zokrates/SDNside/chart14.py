import numpy as np
import matplotlib.pyplot as plt
y = [2,2]
x = ['(Server)','(SDN)']
n_groups = 2
index = np.arange(n_groups)
bars =plt.bar(x, y,color=['mediumseagreen', 'steelblue'],  align='center', width=0.2)
#plt.xlabel("On-chain Solution")
plt.ylabel("Latency (ms)")
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
#plt.title("On-chain solution")
plt.show()