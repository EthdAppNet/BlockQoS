import matplotlib.pyplot as plt
import numpy as np

x= [10,20,30,40,50,60,70,80,90,100] 
y =  [25610,13279,9197,7117,5885,5063,4477,4037,3694,3421]
plt.plot(x, y, color="g")
# Add title and axis names
#plt.title('ONSP Session')
plt.xlabel(r'$BlockQoS\,sessions\,/\,proof$')
plt.ylabel('Gas units')
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
plt.grid(axis = 'x', linestyle = '--', linewidth = 0.5,alpha=1)
for a,b in zip(x, y): 
    plt.text(a-1.5, b, str(b), color="black", size="small")
#plt.legend()
plt.show()



#axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1