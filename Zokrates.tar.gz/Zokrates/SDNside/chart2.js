const plotlib = require('nodeplotlib');
var Base_Subscription = {
  x: ['t1','t2','t3','t4','t5','t6','t7','t8','t9','t10','t11','t12','t13','t14','t15','t16','t17','t18','t19','t20','t21','t22','t23','t24','t25','t26','t27','t28','t29','t30','t31','t32','t33','t34','t35','t36','t37','t38','t29','t40','t41','t42','t43','t44','t46','t47'],
  y: [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200,200,200,200, 200,200,200],
  name: 'ONSP_Session',
  mode: 'scatter',
  line: {
    dash: 'dashdot',
    width: 2,
  },
};
var ONSP_Session = {
  x: ['t2','t3','t4','t5','t6','t7','t8','t9','t10','t11','t12','t13','t14','t15','t16','t17','t18','t19','t20','t21','t22','t23','t24','t25','t26','t27','t28','t29','t30','t31','t32','t33','t34','t35','t36','t37','t38','t29','t40','t41','t42','t43','t44','t46','t47'],
  y: [200, 1200,200,200,800,200,200,900,200,200,200,200,800,200,200,200,200,1800,200,200,800,200,200,1800,200,200,1500,200,200,900,200,200,200,1600,200,200],
  name: 'ONSP_Session',
  mode: 'scatter',
  line: {
    dash: 'dashdot',
    width: 2,
    color:'red'
  },
};
var layout = {
  title:'ONSP_Session (10x requests)',
  yaxis: {
    title: 'Bandwidth (Mbps)',
    showgrid: true,
    zeroline: true,
    zerolinecolor: '#969696',
    range:[0,2000]
    
  },
  xaxis: {
    title: 'Time(Instance)',
    showgrid: false,
    showgrid: true,
    zeroline: true,
    zerolinecolor: '#969696',
    range:['t1','t33']
    
  },
};
var data = [ONSP_Session];
plotlib.plot(data,layout);