
curl -X DELETE http://localhost:8080/qos/queue/0000000000000001
wait
A=' {"port_name": "s1-eth1", "type": "linux-htb", "max_rate": "100000000", "queues":[{"max_rate": "100000000"}, {"min_rate": "2000000"}, {"min_rate":' 
B=$1
C='}]} '
D=$A$B$C
echo $D
curl -X POST -d '${D}' http://localhost:8080/qos/queue/0000000000000001
#curl -X GET http://localhost:8080/qos/queue/0000000000000001