import matplotlib.pyplot as plt
import numpy as np

x = ['t1','t2','t3','t4','t5','t6','t7','t8','t9','t10','t11','t12','t13','t14','t15','t16','t17','t18','t19','t20','t21','t22','t23','t24','t25'] 
y= [200,1200,200,800,200,900,200,800,200,1800,200,200,800,200,1800,200,200,1500,200,200,900,200,200,1200,200]
plt.step(x, y, color="g", label='ONSP')
plt.axhline(y=200, color='b', linestyle='--', label='Base')
# Add title and axis names
plt.title('ONSP Sessions (10x requests)')
plt.xlabel('Time (Instance)')
plt.ylabel('Bandwidth (Mbps)')
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.5,alpha=1)
plt.legend()
plt.show()
