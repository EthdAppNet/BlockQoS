var cors = require('cors');
var express = require('express');
const {exec} = require ('child_process');
const fs = require ('fs'); 
var app = express();
var count= 0; 
var stdoutext;
var witness;
//initializing zokrates 1)compile 2)compue witness 3)generate proof 4)export verifier 
const main_zok =exec ('sh zok.sh 1 2 2 4', 
	(error, stdout, stderr) => {
	//	console.log(stdout);
	//	console.log(stderr);
		if (error !==null){
			console.log('exec error : ${error}');
		}
	});
 
app.use(cors());
app.get('/', function (req, res) {
    res.send('<b>My</b> first express http server');
});
// route with parameters
// matches to : /books/stephenking/category/horror
app.get('/inputs', function(req, res) {
	var input1= req.param('_input1');
	var input2=req.param('_input2');
	var input3=456621004566;
	var input4=input1 *input2 *input3 ;
	console.log('sh myzok.sh'+' '+input1+' '+input2+' '+input3+' '+input4);
	//splitwise
	const zokWitness =exec ('zokrates compute-witness -a'+' '+input1+' '+input2+' '+input3+' '+input4, 
	(error, stdout, stderr) => {
			witness= stdout;
		console.log(stdout);
		console.log(stderr);
		if (error !==null){
			console.log('exec error : ${error}');
		}
	});
	const zokProof =exec ('zokrates generate-proof', 
	(error, stdout, stderr) => {
			count++; 
			//proof=JSON.parse(stdout);
		proof=JSON.parse(fs.readFileSync("proof.json"));
		stdoutext= proof; 
		console.log('this is only a' + proof.proof.a);
		console.log(stderr);
		if (error !==null){
			console.log('exec error : ${error}');
		}

	});
    //console.log(req.params);
   // var username = req.params.user;
   // var category = req.paramas.categorySlug;
res.send(stdoutext);
   // res.send ('<b>My</b> my lil success')
});
app.use(function(req, res, next) {
    res.status(404).send("Sorry, that route doesn't exist. Have a nice day :)");
});
app.listen(3500, function () {
    console.log('Example app listening on port 3500.');
});